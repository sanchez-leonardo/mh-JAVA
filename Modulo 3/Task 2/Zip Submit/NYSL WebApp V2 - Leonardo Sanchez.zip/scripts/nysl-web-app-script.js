function setMapLocation() {
  let url = schedule.stadium_adresses.filter(
    e => e.stadium_name == event.target.previousElementSibling.innerText
  )[0].embed_url;
  document.getElementById('selected-map').setAttribute('src', url);
}

function selectedMapLocation() {
  document
    .getElementById('selected-map')
    .setAttribute('src', event.target.value);
}
