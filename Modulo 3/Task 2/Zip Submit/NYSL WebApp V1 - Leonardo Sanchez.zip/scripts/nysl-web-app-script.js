let tabs = Array.from(document.querySelectorAll('div[id*=tab]'));

function changeTab(id) {
  event.target.parentElement.parentElement.style.display = 'none';
  document.getElementById(id).style.display = 'grid';
}

function goToLocation() {
  document.getElementById('tab-fixture').style.display = 'none';
  document.getElementById('tab-locations').style.display = 'grid';
}
