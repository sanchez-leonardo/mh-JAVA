// Script necesario para agregar a pantalla de inicio con prompt "mini-info bar"

self.addEventListener('fetch', function(event) {
  //logica de manejo de fetch, momentáneamente vacío
});
