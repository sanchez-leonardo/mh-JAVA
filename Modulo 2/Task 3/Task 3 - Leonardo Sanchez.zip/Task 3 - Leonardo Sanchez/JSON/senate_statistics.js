var senStatistics = {
  "number_of_senators" : 0,
  "number_of_democrats" : 0,
  "democrat_vote_pct" : 0,
  "number_of_republicans" : 0,
  "republican_vote_pct" : 0,
  "number_of_independents" : 0,
  "independent_vote_pct" : 0,
  "least_loyal" : 0,
  "most_loyal" : 0,
  "least_engaged" : 0,
  "most_engaged" : 0
 }
