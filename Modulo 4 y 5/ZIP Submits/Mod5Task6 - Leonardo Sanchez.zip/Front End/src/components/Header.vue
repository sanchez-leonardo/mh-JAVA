<template>
  <v-container tag="header" fluid>
    <h1 class="text-center">HARDCORE NAVAL WARFARE SIMULATOR</h1>
  </v-container>
</template>

<script>
export default {
  name: "App-Header"
};
</script>